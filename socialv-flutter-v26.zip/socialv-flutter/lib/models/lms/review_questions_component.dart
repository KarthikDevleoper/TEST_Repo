import 'package:flutter/material.dart';

class ReviewQuestionsComponent extends StatefulWidget {
  const ReviewQuestionsComponent({Key? key}) : super(key: key);

  @override
  State<ReviewQuestionsComponent> createState() => _ReviewQuestionsComponentState();
}

class _ReviewQuestionsComponentState extends State<ReviewQuestionsComponent> {
  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
